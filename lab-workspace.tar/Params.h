/**********************************
 * FILE NAME: Params.h
 *
 * DESCRIPTION: Header file of Parameter class (Revised 2020)
 **********************************/

#ifndef _PARAMS_H_
#define _PARAMS_H_

#include "stdincludes.h"
#include "Params.h"
#include "Member.h"

enum testTYPE { CREATE_TEST, READ_TEST, UPDATE_TEST, DELETE_TEST };
static std::unordered_map<std::string,testTYPE> const testTypeMap = {
		{"CREATE",testTYPE::CREATE_TEST},
		{"READ",testTYPE::READ_TEST},
		{"UPDATE",testTYPE::UPDATE_TEST},
		{"DELETE",testTYPE::DELETE_TEST},
};


/**
 * CLASS NAME: Params
 *
 * DESCRIPTION: Params class describing the test cases
 */
class Params{
public:
	int MAX_NNB;                // max number of neighbors
	int SINGLE_FAILURE;			// single/multi failure
	double MSG_DROP_PROB;		// message drop probability
	double STEP_RATE;		    // dictates the rate of insertion
	int EN_GPSZ;			    // actual number of peers
	int MAX_MSG_SIZE;
	int DROP_MSG;
	int dropmsg;
	int globaltime;
	int allNodesJoined;
	short PORTNUM;
	int CRUDTEST;
	Params();
	void setparams(char *);
	int getcurrtime();
};

#endif /* _PARAMS_H_ */
